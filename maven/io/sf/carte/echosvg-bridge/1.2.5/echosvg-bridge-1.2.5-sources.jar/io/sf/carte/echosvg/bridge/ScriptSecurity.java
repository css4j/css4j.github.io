/*

   See the NOTICE file distributed with this work for additional
   information regarding copyright ownership.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

 */
package io.sf.carte.echosvg.bridge;

/**
 * An interface that allows UserAgents to describe the security constraints
 * desired for scripting.
 *
 * Right now, this interface only has one method, but it may be extended in the
 * future to add finer control over the security settings for scripts.
 *
 * @author <a href="mailto:vhardy@apache.org">Vincent Hardy</a>
 * @author For later modifications, see Git history.
 * @version $Id$
 */
public interface ScriptSecurity {

	/**
	 * Controls whether the script should be loaded or not.
	 *
	 * @throws SecurityException if the script should not be loaded.
	 */
	void checkLoadScript();

}
