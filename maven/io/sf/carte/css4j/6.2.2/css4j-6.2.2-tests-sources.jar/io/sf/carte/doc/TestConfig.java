/*

 Copyright (c) 2005-2026, Carlos Amengual.

 Licensed under a BSD-style License. You can find the license here:
 https://css4j.github.io/LICENSE.txt

 */

// SPDX-License-Identifier: BSD-2-Clause OR BSD-3-Clause

package io.sf.carte.doc;

public class TestConfig {

	public static final boolean REMOTE_TESTS = false;

	public static final String SVG_NAMESPACE_URI = "http://www.w3.org/2000/svg";

}
