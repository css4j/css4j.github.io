/*

 Copyright (c) 2005-2026, Carlos Amengual.

 Licensed under a BSD-style License. You can find the license here:
 https://css4j.github.io/LICENSE.txt

 */

// SPDX-License-Identifier: BSD-2-Clause OR BSD-3-Clause

package io.sf.carte.doc.dom;

class ElementTuple {

	DOMElement element;
	int index;

	ElementTuple() {
		super();
		this.element = null;
		this.index = 0;
	}

}
