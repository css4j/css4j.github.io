/*

   See the NOTICE file distributed with this work for additional
   information regarding copyright ownership.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

 */
package io.sf.carte.echosvg.ext.awt.image.rendered;

import java.awt.image.Raster;
import java.awt.image.SampleModel;
import java.awt.image.WritableRaster;

import io.sf.carte.echosvg.ext.awt.ColorSpaceHintKey;

/**
 * This strips out the source alpha channel into a one band image.
 *
 * @author <a href="mailto:Thomas.DeWeeese@Kodak.com">Thomas DeWeese</a>
 * @author For later modifications, see Git history.
 * @version $Id$
 */
public class FilterAlphaRed extends AbstractRed {

	/**
	 * Construct an alpah channel from the given src, according to the SVG masking
	 * rules.
	 *
	 * @param src The image to convert to an alpha channel (mask image)
	 */
	public FilterAlphaRed(CachableRed src) {
		super(src, src.getBounds(), src.getColorModel(), src.getSampleModel(), src.getTileGridXOffset(),
				src.getTileGridYOffset(), null);

		props.put(ColorSpaceHintKey.PROPERTY_COLORSPACE, ColorSpaceHintKey.VALUE_COLORSPACE_ALPHA);
	}

	@Override
	public WritableRaster copyData(WritableRaster wr) {
		// new Exception("FilterAlphaRed: ").printStackTrace();
		// Get my source.
		CachableRed srcRed = (CachableRed) getSources().get(0);

		SampleModel sm = srcRed.getSampleModel();
		if (sm.getNumBands() == 1)
			// Already one band of data so we just use it...
			return srcRed.copyData(wr);

		PadRed.ZeroRecter.zeroRect(wr);
		Raster srcRas = srcRed.getData(wr.getBounds());
		AbstractRed.copyBand(srcRas, srcRas.getNumBands() - 1, wr, wr.getNumBands() - 1);
		return wr;
	}

}
