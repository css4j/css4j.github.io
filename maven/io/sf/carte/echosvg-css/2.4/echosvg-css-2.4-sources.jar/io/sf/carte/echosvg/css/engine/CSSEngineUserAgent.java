/*

   See the NOTICE file distributed with this work for additional
   information regarding copyright ownership.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

 */
package io.sf.carte.echosvg.css.engine;

/**
 * One line Class Desc
 *
 * Complete Class Desc
 *
 * @author <a href="mailto:deweese@apache.org">l449433</a>
 * @author For later modifications, see Git history.
 * @version $Id$
 */
public interface CSSEngineUserAgent {

	/**
	 * Displays an error resulting from the specified Exception.
	 */
	void displayError(Exception ex);

	/**
	 * Displays a message in the User Agent interface.
	 */
	void displayMessage(String message);

	/**
	 * Report a warning to the user agent.
	 * 
	 * @param message the warning message.
	 */
	default void warn(String message) {
		displayMessage(message);
	}

}
